chrome.runtime.onInstalled.addListener(()=>{console.log("Safe Verifier Extension installed 6")});chrome.sidePanel.setPanelBehavior({openPanelOnActionClick:!0}).catch(e=>console.error(e));
